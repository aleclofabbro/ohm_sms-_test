import type { Criteria, Options } from 'mingo/types'
import type { Modifier, PipelineStage, UpdateConfig } from 'mingo/updater'
import grammar from './grammar/grammar.ohm-bundle.js'
import type { _any, ModelDescriptor, SelectedEntities } from './types.js'

const mingoSemantics = grammar.createSemantics()

// implementare la/e semanticOp
// riceve il `ModelDescriptor` per consultazione per poter:
// - utilizzare il corretto campo id per la selezione elementi nelle `EntityCollection`
// - utilizzare il corretto campo id, o il valore primitivo stesso, nelle operazioni su array per la selezione elementi
// 
// genera un `CompileQueryResult`O
// eventualmente ogni elemento della pipeline verra' eseguito in successione con una `mingo.updateQuery()` a fronte di una collezione di entita'
// mingoSemantics.addOperation(...)
// [mingoSemantics.addOperation(...)]

export type CompileQueryResult = {
  selectedEntities: SelectedEntities
  results: CompileQueryEntityResult[]
}

// rappresenta una operazione in formato mongo query
export type EntityOperation = {
  // gli argomenti di mingo.updateMany()
  condition: Criteria<_any>
  modifier: Modifier<_any> | PipelineStage[]
  updateConfig?: UpdateConfig
  options?: Partial<Omit<Options, 'context'>>
  // il sourceString dell'operazione
  operation: string
}

export type CompileQueryArg = {
  query: string
  modelDescriptor: ModelDescriptor
}
// un CompileQueryEntityResult rappresenta un `SELECT entity` block.
export type CompileQueryEntityResult = {
  entityName: string
  // idsCondition: il mingo match per le entity id
  idsCondition: Criteria<_any> 
  // pipeline: un elemento per ogni operazione
  pipeline: EntityOperation[]
}

export function compileQuery({
  query,
  modelDescriptor,
}: CompileQueryArg): CompileQueryResult {
  // utilizza la/le operazioni `mingoSemantics` 
  // per parsare `query` a fronte del `modelDescriptor`
  // e generare un `compileQueryResult: CompileQueryResult` da ritornare 
  return compileQueryResult
}
